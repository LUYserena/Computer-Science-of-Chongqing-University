x=linspace(-2.5,2.5,20);                 
        y=exp(-x.*x);
        stairs (x,y)
        title('Stairs plot of a bell crure');