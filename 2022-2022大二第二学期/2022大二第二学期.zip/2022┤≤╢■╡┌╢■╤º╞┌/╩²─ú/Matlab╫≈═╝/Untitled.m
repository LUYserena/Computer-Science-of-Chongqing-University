
y=x*sin(x)-1;
plot(x,y)