#1使用Monte-Carlo抛点法计算圆周率
from random import random
from time import perf_counter
from math import sqrt
a1 = int(input("请输入底数："))
a2 = int(input("请输入指数："))
a = pow(a1,a2)
b = 0
start = perf_counter()
for i in range(1,a + 1):
    x,y = random(),random()
    m = sqrt(x**2 + y**2)
    if m < 1.0:
        b += 1
        pi = 4*(b/a)
print("运行时间是：{:.8f}s".format(perf_counter() - start))
print("圆周率的值是：{}".format(pi))

#2使用Monte-Carlo抛点法计算圆周率
from random import random
from time import perf_counter
from math import sqrt
a1 = int(input("请输入底数："))
a2 = int(input("请输入指数："))
a = pow(a1,a2)
b = 0
start = perf_counter()
for i in range(1,a + 1):
    x,y = random(),random()
    m = x**2 + y**2
    if m < 1.0:
        b += 1
        pi = 4*(b/a)
print("运行时间是：{:.8f}s".format(perf_counter() - start))
print("圆周率的值是：{}".format(pi))

#3绘图
a1 = int(input("请输入底数："))
a2 = int(input("请输入指数："))
a = pow(a1,a2)
import random
N,nHits = a,0
xs,ys = [],[]
for i in range(N):
    x = random.random()*2 - 1
    y = random.random()*2 - 1
    xs.append(x)
    ys.append(y)
    if x**2 + y**2 <= 1:
        nHits += 1
pi = 4*nHits/N
print('pi =',pi)
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
fig = plt.figure(figsize = (6,6))
plt.plot(xs,ys,'o',color = 'black',markersize = 1)
c = Circle(xy = (0,0),radius = 1,alpha = 0.4,color = 'black')
plt.gca().add_patch(c)
plt.show()

#matplotlib绘制GDP折线图
import matplotlib.pyplot as plt

x_data = ['2000','2001','2002','2003','2004','2005','2006','2007',\
                '2008','2009','2010','2011','2012','2013','2014',\
                '2015','2016','2017','2018','2019']
y1_data = [1791.00,1976.86,2232.86,2555.72,3034.58,3467.72,3907.23,4676.13,\
                    5793.66,6530.01,7925.58,10011.37,11409.60,12656.69,14262.60,\
                    15719.72,17558.76,19500.27,20363.19,23605.77]
y2_data = [10741.25,12039.25,13502.42,15844.64,18864.62,22557.37,26587.76,\
            31777.01,36796.71,39482.56,46013.06,53210.28,57067.92,62163.97,\
                67809.85,72812.55,80854.91,89705.23,99945.22,107671.07,]
y3_data = [1029.92,1133.27,1243.43,1426.34,1677.80,2005.42,\
    2338.98,2884.11,3561.56,3912.68,4602.16,5701.84,6852.20,8006.79,\
        9266.39,10502.56,11776.73,13540.83,15353.21,16769.34]
plt.plot(x_data,y1_data)
plt.plot(x_data,y2_data)
plt.plot(x_data,y3_data)
plt.show()
