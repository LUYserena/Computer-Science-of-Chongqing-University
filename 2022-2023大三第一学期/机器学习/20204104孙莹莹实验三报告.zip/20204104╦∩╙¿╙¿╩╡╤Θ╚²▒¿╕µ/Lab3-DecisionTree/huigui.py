import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from draw_tree import createPlot
from sklearn.datasets import load_diabetes

# 获取数据子集，分类与回归的做法相同
# 将数据集根据划分特征切分为两类
def splitDataset(x, y, feaSplit, feaValue):
    '''
    input:x(ndarry):特征值
          y(ndarry):标签值
          feaSplit(int):进行划分的特征编号（列数）
          feaValue(int):进行划分的特征对应特征值
    output:x[equal_Idx],y[equal_Idx](ndarry):特征值等于（大于等于）目标特征值的样本与标签
           x[nequal_Idx],y[nequal_Idx](ndarry):特征值不等于（小于）目标特征的样本与标签
    '''
    if isinstance(feaValue, int) or isinstance(feaValue, float):
        # 如果特征值为浮点数(连续特征值)，那么进行连续值离散化
        equal_Idx = np.where(x[:, feaSplit] <= feaValue)  # 找出特征值大于等于fea_alue的样本序号
        nequal_Idx = np.where(x[:, feaSplit] > feaValue)  # 找出特征值小于fea_alue的样本序号
    else:
        equal_Idx = np.where(x[:, feaSplit] == feaValue)  # 找出特征值等于fea_alue的样本序号
        nequal_Idx = np.where(x[:, feaSplit] != feaValue)  # 找出特征值不等于fea_alue的样本序号
    return x[equal_Idx], y[equal_Idx], x[nequal_Idx], y[nequal_Idx]


# 叶子结点均值计算
def regLeaf(y):
    '''
    input:y(array):标签值
    output:(float)均值
    '''
    return np.mean(y)


# 计算数据集的总方差
def regError(y):
    '''
    input:y(array):标签值
    output:(float):总方差
    '''
    return np.var(y) * len(y)


def getBestFeature(x, y, ops=(1, 4)):
    '''
    input:x(ndarry):特征值
          y(array):标签值
          ops(tuple):第一个数为决策树停止划分的最小精度，第二个数为决策树停止划分的最小划分数
    output:bestFeature(int):最好划分特征的下标
           bestSplit(float):最好划分特征对应的特征值
    '''
    m, n = np.shape(x)
    final_s = ops[0]  # 停止的精度
    final_n = ops[1]  # 停止的样本最小划分数
    # 只有一类样本时，输出叶子结点，以及它对应的均值
    if len(np.unique(y)) == 1:
        return None, regLeaf(y)

    # 获取最优特征和特征值
    totalError = regError(y)  # 总的误差
    bestError = np.inf
    bestFeature = 0
    bestSplit = 0

    for i in range(n):
        curFeature = np.unique(x[:, i])
        for firstSplit in curFeature:
            dataX_1, dataY_1, dataX_2, dataY_2 = splitDataset(x, y, i, firstSplit)
            # 不满足最小划分集合，不进行计算
            if dataX_1.shape[0] < final_n or dataX_2.shape[0] < final_n:
                continue
            curError = regError(dataY_1) + regError(dataY_2)
            if curError < bestError:
                bestError = curError
                bestFeature = i
                bestSplit = firstSplit

    # 预剪枝，求解的误差小于最小误差停止继续划分
    if totalError - bestError < final_s:
        return None, regLeaf(y)

    # 一直无法进行划分，在这里进行处理
    dataX_1, dataY_1, dataX_2, dataY_2 = splitDataset(x, y, bestFeature, bestSplit)
    if dataX_1.shape[0] < final_n or dataX_2.shape[0] < final_n:
        return None, regLeaf(y)

    return bestFeature, bestSplit


def regBuildTree(x, y, ops=(1, 4)):
    '''
    input:x(ndarry):特征值
          y(array):标签值
          ops(tuple):第一个数为决策树停止划分的最小精度，第二个数为决策树停止划分的最小划分数
    output:my_tree(dict):生成的CART决策树字典
    '''
    bestFeature, bestval = getBestFeature(x, y, ops)
    if bestFeature == None:
        return bestval

    # 递归建立CART回归决策树
    my_tree = {}
    my_tree['bestFeature'] = bestFeature
    my_tree['bestval'] = bestval
    dataX_1, dataY_1, dataX_2, dataY_2 = splitDataset(x, y, bestFeature, bestval)

    my_tree['left'] = regBuildTree(dataX_1, dataY_1, ops)
    my_tree['right'] = regBuildTree(dataX_2, dataY_2, ops)

    return my_tree


# 预测一条测试数据结果
def predictOne(inputTree, testdata):
    '''
    input:inputTree(dict):CART分类决策树
          xlabel(list):特征属性列表
          testdata(darry):一条测试数据特征值
    output:classLabel(int):测试数据预测结果
    '''
    firstFeature = inputTree[list(inputTree.keys())[0]]  # 对应的特征下标
    firstSplit = inputTree[list(inputTree.keys())[1]]  # 对应特征的分割值

    classLabel = 0.0  # 定义变量classLabel，默认值为0

    if testdata[firstFeature] >= firstSplit:  # 进入右子树
        if type(inputTree['right']).__name__ == 'dict':
            classLabel = predictOne(inputTree['right'], testdata)
        else:
            classLabel = inputTree['right']
    else:
        if type(inputTree['left']).__name__ == 'dict':
            classLabel = predictOne(inputTree['left'], testdata)
        else:
            classLabel = inputTree['left']

    return round(classLabel, 2)


# 预测所有测试数据结果
def predictAll(inputTree, testDataSet):
    '''
    input:inputTree(dict):训练好的决策树
          xlabel(list):特征值标签列表
          testDataSet(ndarray):测试数据集
    output:classLabelAll(list):测试集预测结果列表
    '''
    classLabelAll = []  # 创建空列表
    for testVec in testDataSet:  # 遍历每条数据
        classLabelAll.append(predictOne(inputTree, testVec))  # 将每条数据得到的特征标签添加到列表
    return np.array(classLabelAll)

def getPrintTree(Tree):
    tree = Tree

    # Feature = ['HouseAge','AveRooms','AveBedroom','Latitude','Longtitude']
    Feature = ['age', 'sex', 'bmi', 'bp','s1','s2','s3','s4','s5','x6']
    ss = '-'.join([str(Feature[tree['bestFeature']]),str(tree['bestval'])])
    printTree = {ss:{}}
    if isinstance(tree['left'],float):
         printTree[ss]['小于'] = tree['left']
    else:
        printTree[ss]['小于'] = getPrintTree(tree['left'])
    if isinstance(tree['right'],float):
        printTree[ss]['大于'] = tree['right']
    else:
       printTree[ss]['大于'] = getPrintTree(tree['right'])
    return printTree
#糖尿病数据集

diabetes = load_diabetes()

data = diabetes.data
target = diabetes.target

X = data[:500,:]
y = target[:500]

x_train,x_test,y_train,y_test = train_test_split(X,y,test_size = 0.2,random_state = 666)
#生成CART回归树
cartTree = regBuildTree(x_train,y_train)
print(cartTree)
classlist=predictAll(cartTree,x_test)
print('预测数据',classlist)
print('真实数据',y_test)
print("平均误差为：",abs(np.sum(classlist)-np.sum(y_test))/len(y_test))
dicTree = getPrintTree(cartTree)
createPlot(dicTree)
#波士顿房价数据集

# data = pd.read_excel("housing_data.xlsx")
# X = data.iloc[:1000, :len(data.columns)-1].values
# y = data.iloc[:1000, -1].values
#
# x_train,x_test,y_train,y_test = train_test_split(X,y,test_size = 0.3,random_state = 666)
# #生成CART回归树
# cartTree = regBuildTree(x_train,y_train)
# # print(cartTree)
# classlist=predictAll(cartTree,x_test)
# print('预测数据',classlist)
# print('真实数据',y_test)
# print("平均误差为：",abs(np.sum(classlist)-np.sum(y_test))/len(y_test))
# dicTree = getPrintTree(cartTree)
# createPlot(dicTree)