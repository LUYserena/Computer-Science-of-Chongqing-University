
#用决策树实现分类

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
from sklearn.datasets import load_wine
from draw_tree import createPlot


class Node:
    '''
        description: 树节点
        param {*} self
        param {*} val 内部节点：特征  叶节点：类别
        param {*} tag 特征划分点
        return {*}
        '''

    def __init__(self, val=0.0, tag=None):
        self.val = val
        self.tag = tag
        #左右子树
        self.lc = None
        self.rc = None

    def __str__(self):
        return f'val: {self.val}, tag: {self.tag}'

class Classify:
    '''
        description: 初始化
        param {*} self
        param {*} features 特征名列表
        return {*}
        '''
    def __init__(self,features=None):
        self.tree = None
        self.features = features
        self.dictTree = {} #将其保存为字典

    #计算基尼杂质系数  label:该样本的类别
    def calGini(self,label):
        gini = 0
        for (type, num) in zip(*np.unique(label,return_counts=True)):
            propo = num/len(label)
            gini += propo * (1-propo)
        return gini

    #挑选最优划分
    #col:一个特征的所有值
    #label:类别
    def getBestSplit(self,col,label):
        # 连续值需要排序
        sort_col = np.unique(np.sort(col, axis=0))
        # 计算划分点
        pos = (sort_col[1:] + sort_col[:-1]) / 2

        tmpBestGini = float('inf') #当前最佳基尼系数
        tmpBestSplit = 0 #当前最优划分点
        for spot in pos:
            smallerCol = col < spot
            largerCol = col > spot

            #计算此次划分的基尼指数
            gini = (sum(smallerCol)*self.calGini(label[smallerCol]) + sum(largerCol)*self.calGini(label[largerCol]))/len(label)
            if gini < tmpBestGini:
                tmpBestGini = gini
                tmpBestSplit = spot
        return tmpBestGini,tmpBestSplit

    #建树
    def buildTree(self,data,labels):
        kinds, cnts = np.unique(labels, return_counts=True)  # 类和每类的数量
        #如果样本均属于同一类别，节点标记为该类
        if len(kinds) == 1:
            return Node(kinds[0])
        if data.shape[0] == 0:
            return None
        self.features = list(data.columns)

        bestGini = float('inf') #最优基尼指数
        bestSplit = None #最优划分点
        bestSpot = 0 #最优划分特征

        #遍历每个特征的每个值
        for i in range(data.shape[1]):
            curGini,curSplit = self.getBestSplit(data.iloc[:,i],labels)
            if curGini < bestGini:
                bestGini = curGini
                bestSplit = curSplit
                bestSpot = i

        if bestGini < 1e-3:
            return Node(kinds[cnts.argmax(0)]) # 返回最多的那个类

        #初始化根节点
        tree = Node(self.features[bestSpot],bestSplit)
        # 连续值二分左右子树 递归建树
        left = data.iloc[:,bestSpot] < bestSplit
        right = data.iloc[:,bestSpot] > bestSplit
        tree.lc = self.buildTree(data[left],labels[left])
        tree.rc = self.buildTree(data[right],labels[right])
        return tree

    #传入数据集建树
    def fit(self,x,y):
        print("Start to train...")
        self.tree = self.buildTree(x,y)
        print("End of train")

    #前序遍历树并把树画出来
    def preOrder(self,tree):
        if tree == None:
            return
        print(tree)
        self.preOrder(tree.lc)
        self.preOrder(tree.rc)

    #判断某个样本的类别
    def getLabel(self,x):
        root = self.tree
        tag = root.tag
        while tag is not None:
            idx = self.features.index(root.val)
            if x[idx] < root.tag:
                root = root.lc
            else:
                root = root.rc
            tag = root.tag
        return root.val

    #预测样本输出
    def predict(self,x,y):
        if self.tree == None:
            return
        yPredicted = []
        for ss in x:
            yPredicted.append(self.getLabel(ss))
        yPredicted = np.array(yPredicted)
        if y is not None:
            scores = np.count_nonzero(y==yPredicted)/len(y)
        return yPredicted,scores

    #树结构->字典，方便可视化
    def getDictTree(self, tree):
        tree = tree
        # if tree != None:
        ss = "-".join([str(tree.val),str(tree.tag)])
        dictTree = {ss:{}}
        # print(ss)
        if tree.lc == None and tree.rc == None:
            return tree.val
        dictTree[ss]['小于'] = self.getDictTree(tree.lc)
        dictTree[ss]['不小于'] = self.getDictTree(tree.rc)
        return dictTree

if __name__ == "__main__":
    data = load_wine()
    # data = load_iris()
    x, y = data['data'], data['target']
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)
    x_train = pd.DataFrame(x_train, columns=data.feature_names, index=None)
    clf = Classify()
    clf.fit(x_train, y_train)
    # 前序遍历树
    clf.preOrder(clf.tree)
    y_pred, scores = clf.predict(x_test, y_test)
    print("Accuracy: {}".format(scores))
    print("真实分类: {}".format(y_test))
    print("预测分类: {}".format(y_pred))
    dicTree = clf.getDictTree(clf.tree)
    print(dicTree)
    createPlot(dicTree)